﻿using Flight_UI.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System.Text;

namespace Flight_UI.Services
{
    public class FlightServices:IFlightServices
    {
        private readonly IConfiguration _configuration;
        private string apiBaseUrl;
        private readonly HttpClient _client;
        public FlightServices(IConfiguration configuration, HttpClient client)
        {
            _configuration = configuration;
            _client = client ?? throw new ArgumentNullException(nameof(client));
            apiBaseUrl = _configuration.GetValue<string>("WebAPIBaseUrl");
        }


        public async Task<FlightResponse> FindAllFlights()
        {
            string endpoint = apiBaseUrl + "/GetAllFlights";
            List<FlightDetailViewModel> result = new List<FlightDetailViewModel>();
            FlightResponse flight = new FlightResponse();


            HttpResponseMessage Res = await _client.GetAsync(endpoint);

            
            if (Res.IsSuccessStatusCode)
            {
                var response = Res.Content.ReadAsStringAsync().Result;

                flight = JsonConvert.DeserializeObject<FlightResponse>(response);
            }

            return flight;
        }

        public async Task<bool> AddFlight(FlightDetailViewModel model)
        {

            StringContent content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json");
            string endpoint = apiBaseUrl + "/AddFlight";
            HttpResponseMessage response = await _client.PostAsync(endpoint, content);

            if (response.IsSuccessStatusCode)
            {
                return true;
            }
            return false;

        }

        public async Task<PassengerResponse> FindAllPassengers()
        {
            string endpoint = apiBaseUrl + "/GetAllPassengers";
            List<PassengerViewModel> result = new List<PassengerViewModel>();
            PassengerResponse passenger = new PassengerResponse();

            HttpResponseMessage Res = await _client.GetAsync(endpoint);


            if (Res.IsSuccessStatusCode)
            {
                var response = Res.Content.ReadAsStringAsync().Result;

                passenger = JsonConvert.DeserializeObject<PassengerResponse>(response);
            }


            List<SelectListItem> flightClass = await GetClassList();

            foreach (var item in passenger.Passengers)
            {
                item.FlightClassDescription = flightClass
                    .Where(x => x.Value == item.FlightClass.ToString())
                    .Select(s => s.Text).First();
            }

            return passenger;
        }

        public async Task<bool> AddPassenger(PassengerViewModel model)
        {
            StringContent content = new StringContent(JsonConvert.SerializeObject(model), Encoding.UTF8, "application/json");
            string endpoint = apiBaseUrl + "/AddPassenger";
            HttpResponseMessage response = await _client.PostAsync(endpoint, content);

            if(response.IsSuccessStatusCode)
            {
                return true;
            }
            return false;

        }

        public async Task<PassengerResponse> FindPassengersByFlightNumber(int number)
        {
            string endpoint = apiBaseUrl + "/GetPassengerByFlightNumber?";

            PassengerResponse passenger = new PassengerResponse();
 
            HttpResponseMessage res = await _client.GetAsync(endpoint+$"{number}");
            if (res.IsSuccessStatusCode)
            {
                var response = res.Content.ReadAsStringAsync().Result;

                passenger = JsonConvert.DeserializeObject<PassengerResponse>(response);
            }

            return passenger;
        }

        public async Task<List<SelectListItem>> GetClassList()
        {

            string endpoint = apiBaseUrl + "/GetBaggageRules";
            List<Baggage> result = new List<Baggage>();

            HttpResponseMessage Res = await _client.GetAsync(endpoint);


            if (Res.IsSuccessStatusCode)
            {
                var response = Res.Content.ReadAsStringAsync().Result;

                result = JsonConvert.DeserializeObject<List<Baggage>>(response);
            }
            return (from item in result
                    select new SelectListItem() { Text = item.flightClass, Value = item.id.ToString() }).ToList();
        }

        public async Task<List<Baggage>> GetBaggage()
        {
            string endpoint = apiBaseUrl + "/GetSeatRangeRules";

            List<Baggage> bag = new List<Baggage>();

            HttpResponseMessage Res = await _client.GetAsync(endpoint);


            if (Res.IsSuccessStatusCode)
            {
                var response = Res.Content.ReadAsStringAsync().Result;

                bag = JsonConvert.DeserializeObject<List<Baggage>>(response);
            }

            return bag;
        }

      

        public async Task<List<SelectListItem>> GetFlightList()
        {
            FlightResponse flight = new FlightResponse();
            flight =await FindAllFlights();
           
            return (from item in flight.flights
                    select new SelectListItem() { Text = item.number.ToString(), Value = item.number.ToString() }).ToList();
        }
    }
}
