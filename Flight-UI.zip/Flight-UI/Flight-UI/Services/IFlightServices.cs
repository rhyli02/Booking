﻿using Flight_UI.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Flight_UI.Services
{
    public interface IFlightServices
    {
        Task<FlightResponse> FindAllFlights();
        Task<bool> AddFlight(FlightDetailViewModel model);

        Task<PassengerResponse> FindAllPassengers();

        Task<bool> AddPassenger(PassengerViewModel model);

        Task<PassengerResponse> FindPassengersByFlightNumber( int flightNumber);

        Task<List<Baggage>> GetBaggage();

     
        Task<List<SelectListItem>> GetClassList();
        Task<List<SelectListItem>> GetFlightList();
    }
}
