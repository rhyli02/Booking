﻿namespace Flight_UI.Models
{
    public class SeatRange
    {

        public int id { get; set; }
        public string? seatClass { get; set; }
        public int lowest { get; set; }
        public int highest { get; set; }
    }
}
