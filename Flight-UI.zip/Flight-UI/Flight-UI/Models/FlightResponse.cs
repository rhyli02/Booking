﻿namespace Flight_UI.Models
{
    public class FlightResponse
    {
        public IEnumerable<FlightDetailViewModel>? flights { get; set; }
    }
}
