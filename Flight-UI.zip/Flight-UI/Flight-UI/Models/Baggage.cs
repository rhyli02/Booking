﻿namespace Flight_UI.Models
{
    public class Baggage
    {

        public int id { get; set; }
        public string? flightClass { get; set; }
        public int numberOfBags { get; set; }
        public decimal weight { get; set; }
        public string? unit { get; set; }
    }
}
