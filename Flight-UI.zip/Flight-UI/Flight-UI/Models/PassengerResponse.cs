﻿namespace Flight_UI.Models
{
    public class PassengerResponse
    {
        public IEnumerable<PassengerViewModel>? Passengers { get; set; }
    }
}
