﻿using System.ComponentModel.DataAnnotations;

namespace Flight_UI.Models
{
    public class FlightDetailViewModel
    {
        [Required(ErrorMessage = "Flight Number is required.")]
        public int number { get; set; }
        [Required(ErrorMessage = "Pleasee enter Destination.")]
        public string Destination { get; set; }
    }
}
