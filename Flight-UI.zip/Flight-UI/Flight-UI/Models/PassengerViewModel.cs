﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace Flight_UI.Models
{
    public class PassengerViewModel
    {
        [Required(ErrorMessage = "Pleasee enter First Name")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Pleasee enter Last Name")]
        public string LastName { get; set; }
        [Required(ErrorMessage = "Pleasee select a Class")]
        public int FlightClass { get; set; }
        [Required]
        public float sumOfTicket { get; set; }
        [Required]
        public int FlightNumber { get; set; }
        [Required]
        public int NumberOfBags { get; set; }
        [Required]
        [Range(0, 30, ErrorMessage = "Eexceed the Maximum weight allowed")]
        public decimal TotalWeight { get; set; }
        [Required]
        public String FlightClassDescription { get; set; }
        [Required]
        public int SeatNumber { get; set; }
        [Required]
        public List<SelectListItem> ClassList { get; set; }
        public List<SelectListItem> BagList { get; set; }
        public List<SelectListItem> FlightList { get; set; }
    }
}
