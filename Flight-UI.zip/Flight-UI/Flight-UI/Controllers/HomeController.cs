﻿using Flight_UI.Models;
using Flight_UI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Diagnostics;

namespace Flight_UI.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IFlightServices _services;

        public HomeController(ILogger<HomeController> logger, IFlightServices services)
        {
            _logger = logger;
            _services = services;
        }

        public async Task<IActionResult> Index()
        {
            FlightResponse res = await _services.FindAllFlights();
            return View(res);
        }
        [HttpGet]
        public async Task<IActionResult> Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(FlightDetailViewModel collection)
        {

           bool res = await _services.AddFlight(collection);

            if(res)
            return RedirectToAction(nameof(Index));



            return View();

        }
        public async Task<ActionResult> Passenger()
        {
            PassengerResponse res = await _services.FindAllPassengers();
            return View(res);
        }
        public async Task<ActionResult> PassengerByFn(int flightNumber)
        {
            PassengerResponse res = await _services.FindAllPassengers();
            return View(res);
        }

        [HttpGet]
        public async Task<IActionResult> CreatePassenger()
        {
            List<SelectListItem> lsClass = new List<SelectListItem>();
            lsClass = await _services.GetClassList();
            lsClass.Insert(0, new SelectListItem { Text = "", Value = "" });

            List<SelectListItem> lsBags = new List<SelectListItem>();
            lsBags.Insert(0, new SelectListItem { Text = "0", Value = "0" });
            lsBags.Insert(1, new SelectListItem { Text = "1", Value = "1" });
            lsBags.Insert(2, new SelectListItem { Text = "2", Value = "2" });



            List<SelectListItem> lsFlight = new List<SelectListItem>();
            lsFlight = await _services.GetFlightList();
            lsFlight.Insert(0, new SelectListItem { Text = "", Value = "" });

            PassengerViewModel res = new PassengerViewModel();
            res.ClassList = lsClass;
            res.BagList = lsBags;
            res.FlightList = lsFlight;


          


            return View(res);
        }
        [HttpPost]
        public async Task<ActionResult> CreatePassenger(PassengerViewModel model )
        {

           bool res =await _services.AddPassenger(model);
            if(res)
            return RedirectToAction(nameof(Passenger));



            return View();

        }

        
        [HttpGet]
        public async Task<IActionResult> FlightPassengers(int id)
        {
            PassengerResponse res = await _services.FindPassengersByFlightNumber(id);
            return View(res);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}