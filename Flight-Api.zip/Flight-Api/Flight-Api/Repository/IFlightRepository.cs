﻿using Flight_Api.Model;

namespace Flight_Api.Repository
{
    public interface IFlightRepository
    {
        List<Baggage> GetBaggages();
        List<SeatRange> GetSeatRanges();
        List<Flight> GetFlights();
        List<Passenger> GetPassengers();
        List<Passenger> GetPassengersByFn(int number);
        bool AddFlight(Flight model);
        bool AddPassenger(Passenger model);
    }
}
