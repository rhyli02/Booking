﻿using Flight_Api.Model;

namespace Flight_Api.Repository
{
    public class FlightRepository : IFlightRepository
    {
        public FlightRepository()
        {
            using (var context = new ApiContext())
            {
                var initialBaggage = context.Baggages.FirstOrDefault(b => b.id.Equals(1));
                if (initialBaggage == null)
                {
                            var baggages = new List<Baggage>
                        {
                        new Baggage
                        {
                            flightClass ="Economy Class",
                            numberOfBags = 1,
                            weight =20,
                            unit= "Kilograms"
                        },
                        new Baggage
                        {
                            flightClass ="Business Class",
                            numberOfBags = 2,
                            weight =20,
                            unit= "Kilograms"

                        },
                          new Baggage
                        {
                            flightClass ="First  Class",
                            numberOfBags = 2,
                            weight =30,
                            unit= "Kilograms"

                        }
                        };
                            context.AddRange(baggages);
                            context.SaveChanges();
                }


               /* var initialseatRanges = context.SeatRanges.FirstOrDefault(b => b.id.Equals(1));
                if (initialseatRanges == null)
                {

                            var seatRanges = new List<SeatRange>
                        {
                        new SeatRange
                        {
                            seatClass ="Economy Class",
                            lowest = 51,
                            highest =200

                        },
                        new SeatRange
                        {
                            seatClass ="Business Class",
                             lowest = 21,
                            highest =50

                        },
                        new SeatRange
                        {
                            seatClass ="First  Class",
                             lowest = 1,
                            highest =20

                        }
                        };
                            context.AddRange(seatRanges);
                            context.SaveChanges();
                 }*/


                var initialFlight = context.Flights.FirstOrDefault(b => b.id.Equals(1));
                if (initialFlight == null)
                {
                    var flight = new List<Flight>
                        {
                        new Flight
                        {
                            number =1122,
                            destination= "France"
                        },
                        new Flight
                        {
                            number =2211,
                            destination= "Manila"

                        }
                         
                        };
                    context.AddRange(flight);
                    context.SaveChanges();
                }


                var initialPassenger = context.Passengers.FirstOrDefault(b => b.id.Equals(1));
                if (initialPassenger == null)
                {
                    var passenger = new List<Passenger>
                        {
                        new Passenger
                        {
                            lastName ="Lingad",
                            firstName="Ryan",
                            flightClass= 1,
                            flightNumber = 1122,
                            NumberOfBags = 2,
                            sumOfTicket=2000,
                            TotalWeight=30,
                            SeatNumber = 77
                        }
                       

                        };
                    context.AddRange(passenger);
                    context.SaveChanges();
                }

            }
        }

        public List<Baggage> GetBaggages()
        {
            using (var context = new ApiContext())
            {
                return context.Baggages.ToList();
            }
        }

        public List<SeatRange> GetSeatRanges()
        {
            using (var context = new ApiContext())
            {
                return context.SeatRanges.ToList();
            }
        }

        public List<Flight> GetFlights()
        {
            using (var context = new ApiContext())
            {
                return context.Flights.ToList(); 
            }
        }

        public List<Passenger> GetPassengers()
        {
            using (var context = new ApiContext())
            {
                return context.Passengers.ToList(); 
            }
        }

        public bool AddFlight(Flight model)
        {
            try
            {
                using (var context = new ApiContext())
                {
                    context.Add(model);
                    context.SaveChanges();
                }
                return true;
            }
            catch (Exception)
            {

                return false;
            }
          
        }

        public bool AddPassenger(Passenger model)
        {
            try
            {
                using (var context = new ApiContext())
                {
                    context.Add(model);
                    context.SaveChanges();
                }
                return true;
            }
            catch (Exception)
            {

                return false;
            }
        }

        public List<Passenger> GetPassengersByFn(int number)
        {
            using (var context = new ApiContext())
            {
                return context.Passengers.Where(x=>x.flightNumber.Equals(number)).ToList();
            }
        }
    }
}
