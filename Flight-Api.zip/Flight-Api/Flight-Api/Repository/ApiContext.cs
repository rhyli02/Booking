﻿
using Flight_Api.Model;
using Microsoft.EntityFrameworkCore;

namespace Flight_Api.Repository
{


    public class ApiContext : DbContext
    {

        protected override void OnConfiguring
     (DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseInMemoryDatabase(databaseName: "FlightDb");
        }
        public DbSet<Flight> Flights { get; set; }
        public DbSet<Passenger> Passengers { get; set; }
        public DbSet<Baggage> Baggages { get; set; }
        public DbSet<SeatRange> SeatRanges { get; set; }

      

        }
}
