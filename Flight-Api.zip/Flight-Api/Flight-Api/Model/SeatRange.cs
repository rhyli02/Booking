﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Flight_Api.Model
{
    public class SeatRange
    {

        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int id { get; set; }
        public string seatClass{ get; set; }
        public int lowest { get; set; }
        public int highest { get; set; } 
    }
}
