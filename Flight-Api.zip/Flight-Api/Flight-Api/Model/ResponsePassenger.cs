﻿namespace Flight_Api.Model
{
    public class ResponsePassenger
    {
        public List<Passenger>? Passengers { get; set; }
    }
}
