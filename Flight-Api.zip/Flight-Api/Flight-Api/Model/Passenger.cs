﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Flight_Api.Model
{
    public class Passenger
    {

        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int id { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public int flightClass { get; set; }

        public float sumOfTicket { get; set; }
        public int flightNumber { get; set; }
        public int NumberOfBags { get; set; }
        public decimal TotalWeight { get; set; }

        public int SeatNumber { get; set; }


    }
}
