﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Flight_Api.Model
{
    public class Baggage
    {


        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int id { get; set; }
        public string flightClass { get; set; }
        public int numberOfBags { get; set; }
        public decimal weight { get; set; }
        public string unit { get; set; }

    }
}
