﻿namespace Flight_Api.Model
{
    public class ResponseFlight
    {
        public List<Flight> Flights { get; set; }
    }
}
