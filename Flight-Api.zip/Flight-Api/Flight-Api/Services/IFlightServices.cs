﻿using Flight_Api.Model;

namespace Flight_Api.Services
{
    public interface IFlightServices
    {

        List<Baggage> GetBaggages();
        List<SeatRange> GetSeatRanges();
        ResponseFlight GetFlights();
        ResponsePassenger GetPassengers();

        bool AddFlight(Flight model);
        bool AddPassenger(Passenger model);

        ResponsePassenger GetPassengersByFn(int number);
    }
}
