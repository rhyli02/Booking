﻿using Flight_Api.Model;
using Flight_Api.Repository;

namespace Flight_Api.Services
{
    public class FlightServices : IFlightServices
    {
        readonly IFlightRepository _flightRepository;
        public FlightServices(IFlightRepository flightRepository)
        {
            _flightRepository = flightRepository;
        }

        public bool AddFlight(Flight model)
        {
           return _flightRepository.AddFlight(model);
        }

        public bool AddPassenger(Passenger model)
        {
            return _flightRepository.AddPassenger(model);
        }

        public List<Baggage> GetBaggages()
        {
           return _flightRepository.GetBaggages();
        }

        public ResponseFlight GetFlights()
        {
            ResponseFlight response = new ResponseFlight();
            response.Flights = _flightRepository.GetFlights();
            return response;
        }

        public ResponsePassenger GetPassengers()
        {
            ResponsePassenger res = new ResponsePassenger();
            res.Passengers = _flightRepository.GetPassengers();
            return res;
        }

        public ResponsePassenger GetPassengersByFn( int number)
        {
            ResponsePassenger res = new ResponsePassenger();
            res.Passengers = _flightRepository.GetPassengers();
            return res;
        }

        public List<SeatRange> GetSeatRanges()
        {
            return _flightRepository.GetSeatRanges();
        }
    }
}
