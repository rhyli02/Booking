﻿using Flight_Api.Model;
using Flight_Api.Services;
using Microsoft.AspNetCore.Mvc;


namespace Flight_Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FlightController : ControllerBase
    {

        private readonly IFlightServices _services;

        public FlightController(IFlightServices services)
        {
            _services = services;
        }
     

        [HttpGet("GetAllFlights")]
        public ActionResult<List<Flight>> GetFlight()
        {
            return Ok(_services.GetFlights());
        }

        [HttpGet("GetAllPassengers")]
        public ActionResult<ResponsePassenger> GetPassenger()
        {
            return Ok(_services.GetPassengers());
        }

        [HttpGet("GetBaggageRules")]
        public ActionResult<List<Baggage>> GetBaggage()
        {
            return Ok(_services.GetBaggages());
        }

        [HttpGet("GetSeatRangeRules")]
        public ActionResult<List<SeatRange>> GetSeatRange()
        {
            return Ok(_services.GetSeatRanges());
        }

        [HttpPost("AddFlight")]
        public IActionResult AddFlight([FromBody] Flight model)
        {
            bool res =  _services.AddFlight(model);

            if (res)
                return Ok();


            return NotFound("Flight not Created");
        }

        [HttpPost("AddPassenger")]
        public IActionResult AddPassenger([FromBody] Passenger model)
        {
            bool res = _services.AddPassenger(model);

            if (res)
                return Ok();


            return NotFound("Flight not Created");
        }

        [HttpGet("GetPassengerByFlightNumber")]
        public ActionResult<ResponsePassenger> GetPassengerByFlightNumber( int number)
        {
            return Ok(_services.GetPassengersByFn(number));
        }

    }
}
